<?php 

$config['tmdb_api'] = "cd0478931a5270762d91c320fa5ecccc";
